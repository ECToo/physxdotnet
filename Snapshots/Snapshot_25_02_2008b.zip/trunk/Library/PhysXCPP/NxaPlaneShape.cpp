#include "StdAfx.h"
#include "NxaPlaneShape.h"



NxaPlaneShape::NxaPlaneShape(NxShape* ptr) : NxaShape(ptr)
{
}
