#include "StdAfx.h"
#include "NxaStream.h"

NxaStream::NxaStream()
{

}

NxaStream::~NxaStream()
{

}