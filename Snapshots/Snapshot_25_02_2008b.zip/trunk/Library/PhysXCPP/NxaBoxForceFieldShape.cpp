#include "StdAfx.h"
#include "NxaBoxForceFieldShape.h"

NxaBoxForceFieldShape::NxaBoxForceFieldShape(void)
{
}
