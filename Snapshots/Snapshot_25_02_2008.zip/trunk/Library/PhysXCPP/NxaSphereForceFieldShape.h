#pragma once
#include "nxaforcefieldshape.h"

public ref class NxaSphereForceFieldShape :
public NxaForceFieldShape
{
public:
	NxaSphereForceFieldShape(void);
};
