#pragma once

ref class NxaForceField
{
public:
	NxaForceField(void);
	~NxaForceField(void);
	!NxaForceField(void);
};
