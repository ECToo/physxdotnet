#pragma once
#include "nxaforcefieldshape.h"

public ref class NxaBoxForceFieldShape : public NxaForceFieldShape
{
public:
	NxaBoxForceFieldShape(void);
};