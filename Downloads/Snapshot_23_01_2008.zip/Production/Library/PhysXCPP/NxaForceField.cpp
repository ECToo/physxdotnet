#include "StdAfx.h"
#include "NxaForceField.h"

NxaForceField::NxaForceField(void)
{

}

NxaForceField::~NxaForceField(void)
{

}

NxaForceField::!NxaForceField(void)
{

}