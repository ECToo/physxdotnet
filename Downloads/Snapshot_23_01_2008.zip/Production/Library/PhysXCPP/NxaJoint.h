#pragma once

#include "NxJoint.h"

public ref class NxaJoint abstract
{
internal:
	NxJoint* nxJoint;
		
public:
	NxaJoint(void);
};