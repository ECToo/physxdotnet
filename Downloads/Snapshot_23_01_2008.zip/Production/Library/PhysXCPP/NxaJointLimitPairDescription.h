#pragma once

public ref class NxaJointLimitPairDescription
{
public:
	NxaJointLimitPairDescription(void);
	~NxaJointLimitPairDescription(void);
	!NxaJointLimitPairDescription(void);
};