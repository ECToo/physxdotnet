#include "StdAfx.h"
#include "NxaConvexForceFieldShape.h"

NxaConvexForceFieldShape::NxaConvexForceFieldShape(void)
{
}
