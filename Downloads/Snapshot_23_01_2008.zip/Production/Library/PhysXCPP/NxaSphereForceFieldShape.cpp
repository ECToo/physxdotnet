#include "StdAfx.h"
#include "NxaSphereForceFieldShape.h"

NxaSphereForceFieldShape::NxaSphereForceFieldShape(void)
{
}
