#include "StdAfx.h"
#include "NxaSpringDescription.h"

NxaSpringDescription::NxaSpringDescription(void)
{

}

NxaSpringDescription::~NxaSpringDescription(void)
{

}

NxaSpringDescription::!NxaSpringDescription(void)
{

}