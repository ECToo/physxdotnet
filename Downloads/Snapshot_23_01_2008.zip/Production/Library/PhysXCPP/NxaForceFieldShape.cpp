#include "StdAfx.h"
#include "NxaForceFieldShape.h"

NxaForceFieldShape::NxaForceFieldShape(void)
{
}
