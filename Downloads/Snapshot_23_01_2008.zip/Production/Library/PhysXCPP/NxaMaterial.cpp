#include "StdAfx.h"
#include "NxaMaterial.h"



NxaMaterial::NxaMaterial(void)
{

}

NxaMaterial::~NxaMaterial(void)
{

}

NxaMaterial::!NxaMaterial(void)
{

}