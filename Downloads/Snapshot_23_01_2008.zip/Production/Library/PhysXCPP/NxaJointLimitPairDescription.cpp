#include "StdAfx.h"
#include "NxaJointLimitPairDescription.h"



NxaJointLimitPairDescription::NxaJointLimitPairDescription(void)
{

}

NxaJointLimitPairDescription::~NxaJointLimitPairDescription(void)
{

}

NxaJointLimitPairDescription::!NxaJointLimitPairDescription(void)
{

}