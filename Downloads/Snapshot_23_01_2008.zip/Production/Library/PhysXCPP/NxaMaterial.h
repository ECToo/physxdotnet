#pragma once

public ref class NxaMaterial
{
public:
	NxaMaterial(void);
	~NxaMaterial(void);
	!NxaMaterial(void);
};