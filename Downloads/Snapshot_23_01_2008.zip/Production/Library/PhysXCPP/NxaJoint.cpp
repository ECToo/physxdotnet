#include "StdAfx.h"
#include "NxaJoint.h"


NxaJoint::NxaJoint(void)
{

}