#include "StdAfx.h"
#include "NxaFixedJointDescription.h"

#include "NxFixedJointDesc.h"



NxaFixedJointDescription::NxaFixedJointDescription(void)
{
	nxJointDesc = new NxFixedJointDesc();
}

NxaFixedJointDescription::~NxaFixedJointDescription(void)
{

}

NxaFixedJointDescription::!NxaFixedJointDescription(void)
{

}