#pragma once
#include "nxashape.h"

public ref class NxaPlaneShape : public NxaShape
{
internal:
	NxaPlaneShape(NxShape* ptr);
};