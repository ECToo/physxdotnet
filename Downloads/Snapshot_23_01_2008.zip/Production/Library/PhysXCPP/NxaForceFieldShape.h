#pragma once

public ref class NxaForceFieldShape
{
public:
	NxaForceFieldShape(void);
};
