#pragma once

ref class NxaSpringDescription
{
public:
	NxaSpringDescription(void);
	~NxaSpringDescription(void);
	!NxaSpringDescription(void);
};
