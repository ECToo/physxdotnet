#include "StdAfx.h"
#include "NxaCapsuleForceFieldShape.h"



NxaCapsuleForceFieldShape::NxaCapsuleForceFieldShape(void)
{
}
