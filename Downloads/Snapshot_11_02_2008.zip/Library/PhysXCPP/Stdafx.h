// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

using namespace System;
using namespace System::Collections;
using namespace System::Collections::Generic;

using namespace System::Runtime::InteropServices;

using namespace Microsoft::Xna::Framework;