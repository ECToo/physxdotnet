#pragma once

ref class NxaCloth
{
public:
	NxaCloth(void);
	~NxaCloth(void);
	!NxaCloth(void);
};
