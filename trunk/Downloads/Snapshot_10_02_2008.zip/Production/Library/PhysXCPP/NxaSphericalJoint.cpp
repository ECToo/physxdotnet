#include "StdAfx.h"
#include "NxaSphericalJoint.h"

#include "NxSphericalJoint.h"

NxaSphericalJoint::NxaSphericalJoint(NxSphericalJoint* joint)
{
	nxJoint = joint;
}
