#pragma once

#include "NxaJointDescription.h"
	
public ref class NxaFixedJointDescription : public NxaJointDescription
{
public:
	NxaFixedJointDescription(void);
	~NxaFixedJointDescription(void);
	!NxaFixedJointDescription(void);
};