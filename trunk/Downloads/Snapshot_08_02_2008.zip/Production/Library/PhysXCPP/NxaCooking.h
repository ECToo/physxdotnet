#pragma once

public ref class NxaCooking
{
public:
	static bool InitialiseCooking();
	static void CloseCooking();
};
