#pragma once
#include "nxaforcefieldshape.h"

public ref class NxaCapsuleForceFieldShape : public NxaForceFieldShape
{
public:
	NxaCapsuleForceFieldShape(void);
};