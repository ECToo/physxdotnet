#include "StdAfx.h"
#include "NxaCloth.h"

NxaCloth::NxaCloth(void)
{

}

NxaCloth::~NxaCloth(void)
{

}

NxaCloth::!NxaCloth(void)
{

}
