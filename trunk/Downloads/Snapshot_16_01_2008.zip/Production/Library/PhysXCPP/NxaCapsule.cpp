#include "StdAfx.h"
#include "NxaCapsule.h"

using namespace PhysXCPP;

NxaCapsule::NxaCapsule(void)
{

}

NxaCapsule::!NxaCapsule(void)
{

}
