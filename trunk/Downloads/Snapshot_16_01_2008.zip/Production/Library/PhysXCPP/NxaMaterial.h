#pragma once

#include "NxPhysics.h"

namespace PhysXCPP
{

	public ref class NxaMaterial
	{
	public:
		NxaMaterial(void);
		~NxaMaterial(void);
		!NxaMaterial(void);
	};

}
