#include "StdAfx.h"
#include "NxaSphericalJoint.h"

PhysXCPP::NxaSphericalJoint::NxaSphericalJoint(NxSphericalJoint* joint)
{
	nxJoint = joint;
}
