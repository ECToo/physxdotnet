#include "StdAfx.h"
#include "NxaFixedJointDescription.h"

using namespace PhysXCPP;

NxaFixedJointDescription::NxaFixedJointDescription(void)
{
	nxJointDesc = new NxFixedJointDesc();
}

NxaFixedJointDescription::~NxaFixedJointDescription(void)
{

}

NxaFixedJointDescription::!NxaFixedJointDescription(void)
{

}