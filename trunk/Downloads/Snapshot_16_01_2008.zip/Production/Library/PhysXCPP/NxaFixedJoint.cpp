#include "StdAfx.h"
#include "NxaFixedJoint.h"

using namespace PhysXCPP;

NxaFixedJoint::NxaFixedJoint(NxFixedJoint* joint)
{
	nxJoint = joint;
}

NxaFixedJoint::~NxaFixedJoint(void)
{

}

NxaFixedJoint::!NxaFixedJoint(void)
{

}