#include "StdAfx.h"
#include "NxaBodyDescription.h"
#include "NxPhysics.h"

using namespace PhysXCPP;

NxaBodyDescription::NxaBodyDescription(void)
{
	nxBodyDesc = new NxBodyDesc();
}

NxaBodyDescription::!NxaBodyDescription()
{

}
