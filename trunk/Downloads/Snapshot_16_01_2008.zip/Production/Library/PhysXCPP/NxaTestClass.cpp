#include "StdAfx.h"
#include "NxaTestClass.h"

NxaTestClass::NxaTestClass(void)
{
}

NxaTestClass::~NxaTestClass(void)
{
}
