#include "StdAfx.h"
#include "NxaBoxForceFieldShape.h"

using namespace PhysXCPP;

NxaBoxForceFieldShape::NxaBoxForceFieldShape(void)
{
}
