#pragma once
#include "nxaforcefieldshape.h"

namespace PhysXCPP
{

	public ref class NxaCapsuleForceFieldShape : public NxaForceFieldShape
	{
	public:
		NxaCapsuleForceFieldShape(void);
	};

}