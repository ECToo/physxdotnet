#include "StdAfx.h"
#include "NxaJointLimitPairDescription.h"

using namespace PhysXCPP;

NxaJointLimitPairDescription::NxaJointLimitPairDescription(void)
{

}

NxaJointLimitPairDescription::~NxaJointLimitPairDescription(void)
{

}

NxaJointLimitPairDescription::!NxaJointLimitPairDescription(void)
{

}