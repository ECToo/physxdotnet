#pragma once
#include "nxashape.h"

namespace PhysXCPP
{

	public ref class NxaCapsuleShape : 	public NxaShape
	{
	public:
		NxaCapsuleShape(NxShape* ptr);
	};

}