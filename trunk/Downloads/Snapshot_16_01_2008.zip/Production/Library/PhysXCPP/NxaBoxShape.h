#pragma once
#include "nxashape.h"

namespace PhysXCPP
{

	public ref class NxaBoxShape : public NxaShape
	{
	public:
		NxaBoxShape(NxShape* ptr);

		Vector3 GetDimensions();
	};

}