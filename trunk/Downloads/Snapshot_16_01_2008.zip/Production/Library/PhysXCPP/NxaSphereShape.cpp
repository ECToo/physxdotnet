#include "StdAfx.h"
#include "NxaSphereShape.h"

using namespace PhysXCPP;

NxaSphereShape::NxaSphereShape(NxShape *ptr) : NxaShape(ptr)
{
}