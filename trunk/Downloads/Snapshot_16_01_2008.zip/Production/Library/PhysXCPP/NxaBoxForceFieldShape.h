#pragma once
#include "nxaforcefieldshape.h"


namespace PhysXCPP
{
	public ref class NxaBoxForceFieldShape : public NxaForceFieldShape
	{
	public:
		NxaBoxForceFieldShape(void);
	};
}