#pragma once

namespace PhysXCPP
{

	public ref class NxaJointLimitPairDescription
	{
	public:
		NxaJointLimitPairDescription(void);
		~NxaJointLimitPairDescription(void);
		!NxaJointLimitPairDescription(void);
	};

}
