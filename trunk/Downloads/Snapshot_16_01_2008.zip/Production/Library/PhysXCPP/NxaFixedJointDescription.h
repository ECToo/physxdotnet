#pragma once

#include "NxaJointDescription.h"

namespace PhysXCPP
{

	public ref class NxaFixedJointDescription : public NxaJointDescription
	{
	public:
		NxaFixedJointDescription(void);
		~NxaFixedJointDescription(void);
		!NxaFixedJointDescription(void);
	};

}