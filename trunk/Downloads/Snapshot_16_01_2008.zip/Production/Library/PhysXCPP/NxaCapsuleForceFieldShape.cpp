#include "StdAfx.h"
#include "NxaCapsuleForceFieldShape.h"

using namespace PhysXCPP;

NxaCapsuleForceFieldShape::NxaCapsuleForceFieldShape(void)
{
}
