#pragma once

namespace PhysXCPP
{

	public ref class NxaCapsule
	{
	public:
		NxaCapsule(void);
		!NxaCapsule(void);
	};

}