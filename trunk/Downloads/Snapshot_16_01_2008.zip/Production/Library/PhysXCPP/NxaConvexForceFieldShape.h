#pragma once
#include "nxaforcefieldshape.h"

public ref class NxaConvexForceFieldShape :
public NxaForceFieldShape
{
public:
	NxaConvexForceFieldShape(void);
};
