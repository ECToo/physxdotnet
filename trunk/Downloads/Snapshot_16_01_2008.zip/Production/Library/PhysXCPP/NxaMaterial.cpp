#include "StdAfx.h"
#include "NxaMaterial.h"
#include "NxPhysics.h"

using namespace PhysXCPP;

NxaMaterial::NxaMaterial(void)
{

}

NxaMaterial::~NxaMaterial(void)
{

}

NxaMaterial::!NxaMaterial(void)
{

}