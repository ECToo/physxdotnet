#include "StdAfx.h"
#include "NxaCapsuleShape.h"

using namespace PhysXCPP;

NxaCapsuleShape::NxaCapsuleShape(NxShape* ptr) : NxaShape(ptr)
{
}
