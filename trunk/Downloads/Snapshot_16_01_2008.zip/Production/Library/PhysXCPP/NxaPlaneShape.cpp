#include "StdAfx.h"
#include "NxaPlaneShape.h"

using namespace PhysXCPP;

NxaPlaneShape::NxaPlaneShape(NxShape* ptr) : NxaShape(ptr)
{
}
