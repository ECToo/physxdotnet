#include "StdAfx.h"
#include "NxaSceneDescription.h"

using namespace PhysXCPP;

NxaSceneDescription::NxaSceneDescription(void)
{

}

NxaSceneDescription::!NxaSceneDescription(void)
{

}